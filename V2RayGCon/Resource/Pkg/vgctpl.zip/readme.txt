Update: 
2018-10-27

Usage: 
https://github.com/nobody3u/VGCTpl/wiki

