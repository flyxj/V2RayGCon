Update: 
2018-11-17

Usage: 
https://github.com/nobody3u/VGCTpl/wiki

